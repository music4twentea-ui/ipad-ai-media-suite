import SwiftUI
import Foundation
import CoreML
import Vision
import UniformTypeIdentifiers
import Compression
import UIKit

// MARK: - CoreML Package Search, Inspector & .mlpackage -> .mlmodel Converter App
// Paste this entire file directly into `ContentView.swift` in a new iPad Swift Playgrounds App.
// Optimized for instant Swift Playgrounds compilation and zero-hang startup:
// - Modularized SwiftUI subviews prevent the iPad Swift Playgrounds type-checker / preview instrumenter from stalling during build.
// - Zero network or file I/O tasks run inside `init()`.

public struct ZooCatalogManifest: Codable, Sendable {
    public let manifest_version: Int?
    public let updated_at: String?
    public let models: [ZooModelEntry]
}

public struct ZooModelEntry: Identifiable, Codable, Equatable, Sendable {
    public var id: String
    public var name: String
    public var subtitle: String
    public var category_id: String
    public var description_md: String
    public var files: [ZooModelFile]
    
    public init(
        id: String,
        name: String,
        subtitle: String,
        category_id: String,
        description_md: String,
        files: [ZooModelFile]
    ) {
        self.id = id
        self.name = name
        self.subtitle = subtitle
        self.category_id = category_id
        self.description_md = description_md
        self.files = files
    }
}

public struct ZooModelFile: Identifiable, Codable, Equatable, Sendable {
    public var id: String { name }
    public var name: String
    public var url: String
    public var archive: String?
    public var size_bytes: Int64?
    public var compute_units: String?
    public var kind: String?
    
    public var formattedSize: String {
        guard let bytes = size_bytes, bytes > 0 else { return "Package" }
        let mb = Double(bytes) / (1024.0 * 1024.0)
        if mb >= 1000 {
            return String(format: "%.2f GB", mb / 1024.0)
        }
        return String(format: "%.1f MB", mb)
    }
}

public struct HFSearchModelItem: Identifiable, Codable, Sendable {
    public var id: String
    public var modelId: String?
    public var likes: Int?
    public var downloads: Int?
    public var pipeline_tag: String?
}

public struct ConvertedModelArtifact: Identifiable, Equatable {
    public let id = UUID()
    public let baseName: String
    public let sourcePackageURL: URL
    public let extractedRawMLModelURL: URL?
    public let compiledMLModelBundleURL: URL?
    public let compiledMLModelCURL: URL?
    public let weightsFileURL: URL?
    public let hasExternalMILWeights: Bool
    public let inputDescriptions: [String]
    public let outputDescriptions: [String]
    public let computeUnitsLabel: String
    public let totalSizeMB: Double
}

// MARK: - Standalone Zip Extractor (Zero External Dependencies)

public final class PackageZipUtility {
    public static func extractZip(at sourceURL: URL, to destinationURL: URL) throws -> [URL] {
        try FileManager.default.createDirectory(at: destinationURL, withIntermediateDirectories: true)
        let fileData = try Data(contentsOf: sourceURL)
        var extractedFiles: [URL] = []
        var offset = 0
        let count = fileData.count
        
        while offset + 30 <= count {
            let sig = fileData.subdata(in: offset..<offset+4).withUnsafeBytes { $0.load(as: UInt32.self) }
            if sig == 0x04034b50 {
                let compMethod = fileData.subdata(in: offset+8..<offset+10).withUnsafeBytes { $0.load(as: UInt16.self) }
                let compSize = Int(fileData.subdata(in: offset+18..<offset+22).withUnsafeBytes { $0.load(as: UInt32.self) })
                let uncompSize = Int(fileData.subdata(in: offset+22..<offset+26).withUnsafeBytes { $0.load(as: UInt32.self) })
                let nameLen = Int(fileData.subdata(in: offset+26..<offset+28).withUnsafeBytes { $0.load(as: UInt16.self) })
                let extraLen = Int(fileData.subdata(in: offset+28..<offset+30).withUnsafeBytes { $0.load(as: UInt16.self) })
                
                let nameOffset = offset + 30
                guard nameOffset + nameLen <= count else { break }
                let nameData = fileData.subdata(in: nameOffset..<nameOffset+nameLen)
                let filename = String(data: nameData, encoding: .utf8) ?? "file_\(offset)"
                
                let dataOffset = nameOffset + nameLen + extraLen
                guard dataOffset + compSize <= count else { break }
                let payloadData = fileData.subdata(in: dataOffset..<dataOffset+compSize)
                let targetFileURL = destinationURL.appendingPathComponent(filename)
                
                if filename.hasSuffix("/") {
                    try? FileManager.default.createDirectory(at: targetFileURL, withIntermediateDirectories: true)
                } else {
                    try? FileManager.default.createDirectory(at: targetFileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
                    if compMethod == 0 {
                        try payloadData.write(to: targetFileURL)
                        extractedFiles.append(targetFileURL)
                    } else if compMethod == 8 {
                        if let decompressed = decompressDeflate(data: payloadData, uncompressedSize: uncompSize) {
                            try decompressed.write(to: targetFileURL)
                            extractedFiles.append(targetFileURL)
                        } else {
                            try payloadData.write(to: targetFileURL)
                            extractedFiles.append(targetFileURL)
                        }
                    }
                }
                offset = dataOffset + compSize
            } else if sig == 0x02014b50 || sig == 0x06054b50 {
                break
            } else {
                offset += 1
            }
        }
        return extractedFiles
    }
    
    private static func decompressDeflate(data: Data, uncompressedSize: Int) -> Data? {
        guard uncompressedSize > 0 else { return Data() }
        var dest = Data(count: uncompressedSize)
        let actual = dest.withUnsafeMutableBytes { (destBytes: UnsafeMutableRawBufferPointer) -> Int in
            data.withUnsafeBytes { (srcBytes: UnsafeRawBufferPointer) -> Int in
                compression_decode_buffer(
                    destBytes.baseAddress!.assumingMemoryBound(to: UInt8.self),
                    uncompressedSize,
                    srcBytes.baseAddress!.assumingMemoryBound(to: UInt8.self),
                    data.count,
                    nil,
                    COMPRESSION_ZLIB
                )
            }
        }
        return actual > 0 ? dest.prefix(actual) : nil
    }
}

// MARK: - ViewModel for Searching, Downloading & Converting .mlpackage -> .mlmodel

@MainActor
public final class CoreMLPackageConverterViewModel: ObservableObject {
    @Published public var searchQuery: String = ""
    @Published public var selectedCategory: String = "all"
    @Published public var customDownloadURLString: String = ""
    
    @Published public var zooModels: [ZooModelEntry] = CoreMLPackageConverterViewModel.defaultCatalog()
    @Published public var hfSearchResults: [HFSearchModelItem] = []
    @Published public var isSearchingHF: Bool = false
    
    @Published public var isBusy: Bool = false
    @Published public var busyStatusText: String = "Ready"
    @Published public var downloadProgress: Double = 0.0
    @Published public var errorMessage: String? = nil
    
    @Published public var convertedArtifacts: [ConvertedModelArtifact] = []
    @Published public var activeExportURLs: [URL] = []
    @Published public var showFileExporter: Bool = false
    @Published public var showShareSheet: Bool = false
    
    private var activeTask: Task<Void, Never>? = nil
    
    public static let categories: [(id: String, title: String, icon: String)] = [
        ("all", "All Models", "square.grid.2x2.fill"),
        ("enhancement", "Super-Res & Enhance", "wand.and.stars"),
        ("restoration", "Face Restore", "face.smiling.fill"),
        ("segmentation", "Face Parsing & Seg", "person.and.background.dotted"),
        ("detection", "Object Detection", "viewfinder"),
        ("depth", "Depth & 3D", "cube.transparent"),
        ("video", "Video Matting", "film")
    ]
    
    // Built via function rather than huge static literal so Swift Playgrounds compiles instantaneously
    public static func defaultCatalog() -> [ZooModelEntry] {
        var list: [ZooModelEntry] = []
        list.append(ZooModelEntry(
            id: "realesrgan",
            name: "Real-ESRGAN 4x (x4plus)",
            subtitle: "Single-Package 4× Super-Resolution (512→2048)",
            category_id: "enhancement",
            description_md: "Full 23-block RRDBNet blind super-resolution in a single .mlpackage (computeUnits: .all).",
            files: [
                ZooModelFile(
                    name: "RealESRGAN_x4.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/realesrgan/RealESRGAN_x4.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 62076023,
                    compute_units: "all",
                    kind: "model"
                )
            ]
        ))
        list.append(ZooModelEntry(
            id: "gfpgan",
            name: "GFPGAN v1.4 Face Restoration",
            subtitle: "Single-Package Blind Face Restoration (512×512)",
            category_id: "restoration",
            description_md: "Restores facial details, eyes, teeth, and natural skin texture in a single .mlpackage.",
            files: [
                ZooModelFile(
                    name: "GFPGAN.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/gfpgan/GFPGAN.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 312748093,
                    compute_units: "all",
                    kind: "model"
                )
            ]
        ))
        list.append(ZooModelEntry(
            id: "face_parsing",
            name: "Face Parsing (19-Class BiSeNet)",
            subtitle: "Single-Package Semantic Face Segmentation (512×512)",
            category_id: "segmentation",
            description_md: "Segments faces into 19 semantic regions (skin, nose, eyes, brows, lips, hair, neck) to softly blend GFPGAN outputs.",
            files: [
                ZooModelFile(
                    name: "FaceParsing.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/faceparsing/FaceParsing.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 49431568,
                    compute_units: "all",
                    kind: "model"
                )
            ]
        ))
        list.append(ZooModelEntry(
            id: "sinsr",
            name: "SinSR (Single-Step Diffusion 4× SR)",
            subtitle: "3-Package Sequential Pipeline (Encoder + Denoiser + Decoder)",
            category_id: "enhancement",
            description_md: "CVPR 2024 single-step diffusion super-resolution (256→1024). Split into 3 packages because Encoder/Decoder use cpuAndGPU (FP16) while the 420 MB Denoiser requires cpuOnly (FP32).",
            files: [
                ZooModelFile(
                    name: "SinSR_Encoder.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/sinsr/SinSR_Encoder.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 41246338,
                    compute_units: "cpuAndGPU",
                    kind: "model"
                ),
                ZooModelFile(
                    name: "SinSR_Denoiser.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/sinsr/SinSR_Denoiser.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 440014511,
                    compute_units: "cpuOnly",
                    kind: "model"
                ),
                ZooModelFile(
                    name: "SinSR_Decoder.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/sinsr/SinSR_Decoder.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 60880285,
                    compute_units: "cpuAndGPU",
                    kind: "model"
                )
            ]
        ))
        list.append(ZooModelEntry(
            id: "ddcolor",
            name: "DDColor Tiny",
            subtitle: "Automatic Image & Video Colorization (512×512)",
            category_id: "enhancement",
            description_md: "Dual-decoder automatic colorization in a single .mlpackage.",
            files: [
                ZooModelFile(
                    name: "DDColor_Tiny.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/ddcolor/DDColor_Tiny.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 212344570,
                    compute_units: "all",
                    kind: "model"
                )
            ]
        ))
        list.append(ZooModelEntry(
            id: "rmbg_1_4",
            name: "RMBG-1.4 Background Removal",
            subtitle: "High-Precision Alpha Matte Segmentation (1024×1024)",
            category_id: "segmentation",
            description_md: "BRIA AI foreground/background alpha matte extraction.",
            files: [
                ZooModelFile(
                    name: "RMBG_1_4.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/rmbg/RMBG_1_4.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 38771210,
                    compute_units: "cpuOnly",
                    kind: "model"
                )
            ]
        ))
        list.append(ZooModelEntry(
            id: "moge2_vitb_normal_504",
            name: "MoGe-2 ViT-B Metric Depth & Normals",
            subtitle: "CVPR 2025 Monocular 3D Geometry (504×504)",
            category_id: "depth",
            description_md: "Predicts metric depth, surface normals, and confidence mask in one pass.",
            files: [
                ZooModelFile(
                    name: "MoGe2_ViTB_Normal_504.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/moge2/MoGe2_ViTB_Normal_504.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 193312088,
                    compute_units: "all",
                    kind: "model"
                )
            ]
        ))
        list.append(ZooModelEntry(
            id: "yolo26s",
            name: "YOLO26s End-to-End Detector",
            subtitle: "NMS-Free Object Detection (640×640)",
            category_id: "detection",
            description_md: "Edge-first NMS-free YOLO detector with 80 COCO classes.",
            files: [
                ZooModelFile(
                    name: "yolo26s.mlpackage.zip",
                    url: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/yolo26/yolo26s.mlpackage.zip",
                    archive: "zip",
                    size_bytes: 17697581,
                    compute_units: "all",
                    kind: "model"
                )
            ]
        ))
        return list
    }
    
    // Zero-work init so Swift Playgrounds never hangs on launch or preview creation
    public init() {}
    
    public var filteredZooModels: [ZooModelEntry] {
        let q = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return zooModels.filter { entry in
            let matchesCat = (selectedCategory == "all") || (entry.category_id == selectedCategory)
            guard matchesCat else { return false }
            guard !q.isEmpty else { return true }
            return entry.name.lowercased().contains(q)
                || entry.subtitle.lowercased().contains(q)
                || entry.description_md.lowercased().contains(q)
                || entry.files.contains(where: { $0.name.lowercased().contains(q) })
        }
    }
    
    public var outputDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("ConvertedCoreMLModels", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
    
    public func cancelCurrentOperation() {
        activeTask?.cancel()
        activeTask = nil
        isBusy = false
        busyStatusText = "Cancelled"
    }
    
    public func refreshRemoteManifest() {
        Task {
            guard let url = URL(string: "https://huggingface.co/mlboydaisuke/coreml-zoo/resolve/main/models.json") else { return }
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = 10
            let session = URLSession(configuration: config)
            if let (data, _) = try? await session.data(from: url),
               let decoded = try? JSONDecoder().decode(ZooCatalogManifest.self, from: data),
               !decoded.models.isEmpty {
                self.zooModels = decoded.models
            }
        }
    }
    
    public func searchHuggingFaceCoreMLRepos() {
        let q = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else {
            hfSearchResults = []
            return
        }
        isSearchingHF = true
        Task {
            defer { isSearchingHF = false }
            let encodedQ = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? q
            guard let url = URL(string: "https://huggingface.co/api/models?search=\(encodedQ)&filter=coreml&limit=12") else { return }
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = 10
            let session = URLSession(configuration: config)
            if let (data, _) = try? await session.data(from: url),
               let items = try? JSONDecoder().decode([HFSearchModelItem].self, from: data) {
                self.hfSearchResults = items
            }
        }
    }
    
    public func downloadAndConvert(file: ZooModelFile) {
        guard let remoteURL = URL(string: file.url) else {
            errorMessage = "Invalid URL: \(file.url)"
            return
        }
        downloadAndConvertFromURL(remoteURL, preferredName: file.name, computeUnitsLabel: file.compute_units ?? "all")
    }
    
    public func downloadAndConvertFromURL(_ remoteURL: URL, preferredName: String? = nil, computeUnitsLabel: String = "all") {
        guard !isBusy else { return }
        isBusy = true
        downloadProgress = 0.08
        let fileName = preferredName ?? remoteURL.lastPathComponent
        busyStatusText = "Downloading \(fileName)..."
        
        activeTask = Task {
            do {
                let (tempDownloadURL, _) = try await URLSession.shared.download(from: remoteURL)
                try Task.checkCancellation()
                downloadProgress = 0.55
                busyStatusText = "Unarchiving & locating .mlpackage..."
                
                let stagingDir = FileManager.default.temporaryDirectory.appendingPathComponent("Staging_\(UUID().uuidString)", isDirectory: true)
                try? FileManager.default.createDirectory(at: stagingDir, withIntermediateDirectories: true)
                let localArchiveURL = stagingDir.appendingPathComponent(fileName)
                try? FileManager.default.removeItem(at: localArchiveURL)
                try FileManager.default.moveItem(at: tempDownloadURL, to: localArchiveURL)
                
                let artifact = try await processAndConvertLocalItem(at: localArchiveURL, computeUnitsLabel: computeUnitsLabel)
                try Task.checkCancellation()
                convertedArtifacts.insert(artifact, at: 0)
                downloadProgress = 1.0
                busyStatusText = "Converted \(artifact.baseName) to .mlmodel!"
                isBusy = false
            } catch is CancellationError {
                busyStatusText = "Cancelled"
                isBusy = false
            } catch {
                errorMessage = "Download/Conversion failed: \(error.localizedDescription)"
                busyStatusText = "Failed"
                isBusy = false
            }
        }
    }
    
    public func handlePickedLocalURLs(_ urls: [URL]) {
        guard let first = urls.first, !isBusy else { return }
        isBusy = true
        downloadProgress = 0.20
        busyStatusText = "Reading \(first.lastPathComponent)..."
        
        activeTask = Task {
            let scoped = first.startAccessingSecurityScopedResource()
            defer {
                if scoped { first.stopAccessingSecurityScopedResource() }
            }
            do {
                let stagingDir = FileManager.default.temporaryDirectory.appendingPathComponent("LocalPick_\(UUID().uuidString)", isDirectory: true)
                try? FileManager.default.createDirectory(at: stagingDir, withIntermediateDirectories: true)
                let localCopy = stagingDir.appendingPathComponent(first.lastPathComponent)
                try? FileManager.default.removeItem(at: localCopy)
                try FileManager.default.copyItem(at: first, to: localCopy)
                
                let artifact = try await processAndConvertLocalItem(at: localCopy, computeUnitsLabel: "all")
                convertedArtifacts.insert(artifact, at: 0)
                downloadProgress = 1.0
                busyStatusText = "Converted \(artifact.baseName) to .mlmodel!"
                isBusy = false
            } catch {
                errorMessage = "Conversion error: \(error.localizedDescription)"
                busyStatusText = "Failed"
                isBusy = false
            }
        }
    }
    
    private func processAndConvertLocalItem(at sourceURL: URL, computeUnitsLabel: String) async throws -> ConvertedModelArtifact {
        let outDir = outputDirectory
        let ext = sourceURL.pathExtension.lowercased()
        
        var workingRoot = sourceURL
        if ext == "zip" {
            let unzipDir = sourceURL.deletingLastPathComponent().appendingPathComponent("Unzipped_\(UUID().uuidString.prefix(6))", isDirectory: true)
            _ = try PackageZipUtility.extractZip(at: sourceURL, to: unzipDir)
            workingRoot = unzipDir
        }
        
        let mlpackageURL = findItem(withExtension: "mlpackage", in: workingRoot)
        let mlmodelURL = findItem(withExtension: "mlmodel", in: workingRoot)
        
        guard let targetPackageOrModel = mlpackageURL ?? mlmodelURL else {
            throw NSError(
                domain: "CoreMLConverter",
                code: 404,
                userInfo: [NSLocalizedDescriptionKey: "No .mlpackage or .mlmodel found inside \(sourceURL.lastPathComponent)."]
            )
        }
        
        let baseName = targetPackageOrModel.deletingPathExtension().lastPathComponent
            .replacingOccurrences(of: ".mlpackage", with: "")
        let modelOutputFolder = outDir.appendingPathComponent(baseName, isDirectory: true)
        try? FileManager.default.removeItem(at: modelOutputFolder)
        try FileManager.default.createDirectory(at: modelOutputFolder, withIntermediateDirectories: true)
        
        let savedPackageURL = modelOutputFolder.appendingPathComponent("\(baseName).mlpackage")
        try? FileManager.default.removeItem(at: savedPackageURL)
        try FileManager.default.copyItem(at: targetPackageOrModel, to: savedPackageURL)
        
        // 1. Extract internal `Data/com.apple.CoreML/model.mlmodel` protobuf specification
        var extractedSpecURL: URL? = nil
        var extractedWeightsURL: URL? = nil
        var hasExternalWeights = false
        
        let internalSpecCandidate = savedPackageURL
            .appendingPathComponent("Data")
            .appendingPathComponent("com.apple.CoreML")
            .appendingPathComponent("model.mlmodel")
        let internalWeightsCandidate = savedPackageURL
            .appendingPathComponent("Data")
            .appendingPathComponent("com.apple.CoreML")
            .appendingPathComponent("weights")
            .appendingPathComponent("weight.bin")
        
        if FileManager.default.fileExists(atPath: internalSpecCandidate.path) {
            let destSpec = modelOutputFolder.appendingPathComponent("\(baseName)_Spec.mlmodel")
            try? FileManager.default.copyItem(at: internalSpecCandidate, to: destSpec)
            extractedSpecURL = destSpec
        }
        if FileManager.default.fileExists(atPath: internalWeightsCandidate.path) {
            hasExternalWeights = true
            let destWeights = modelOutputFolder.appendingPathComponent("weight.bin")
            try? FileManager.default.copyItem(at: internalWeightsCandidate, to: destWeights)
            extractedWeightsURL = destWeights
        }
        
        // 2. Compile on-device via `MLModel.compileModel(at:)`
        busyStatusText = "Compiling \(baseName) on Apple Silicon..."
        downloadProgress = 0.80
        let tempCompiledURL = try await MLModel.compileModel(at: savedPackageURL)
        
        let savedMLModelCURL = modelOutputFolder.appendingPathComponent("\(baseName).mlmodelc", isDirectory: true)
        try? FileManager.default.removeItem(at: savedMLModelCURL)
        try FileManager.default.copyItem(at: tempCompiledURL, to: savedMLModelCURL)
        
        let standaloneMLModelURL = modelOutputFolder.appendingPathComponent("\(baseName).mlmodel")
        try? FileManager.default.removeItem(at: standaloneMLModelURL)
        if !hasExternalWeights, let spec = extractedSpecURL {
            try FileManager.default.copyItem(at: spec, to: standaloneMLModelURL)
        } else {
            try FileManager.default.copyItem(at: tempCompiledURL, to: standaloneMLModelURL)
        }
        
        var inputDescs: [String] = []
        var outputDescs: [String] = []
        let config = MLModelConfiguration()
        config.computeUnits = .cpuOnly
        if let loadedModel = try? MLModel(contentsOf: savedMLModelCURL, configuration: config) {
            for (name, desc) in loadedModel.modelDescription.inputDescriptionsByName {
                inputDescs.append("\(name): \(describeFeature(desc))")
            }
            for (name, desc) in loadedModel.modelDescription.outputDescriptionsByName {
                outputDescs.append("\(name): \(describeFeature(desc))")
            }
        }
        
        let totalMB = directorySizeInMB(at: savedPackageURL)
        return ConvertedModelArtifact(
            baseName: baseName,
            sourcePackageURL: savedPackageURL,
            extractedRawMLModelURL: extractedSpecURL,
            compiledMLModelBundleURL: standaloneMLModelURL,
            compiledMLModelCURL: savedMLModelCURL,
            weightsFileURL: extractedWeightsURL,
            hasExternalMILWeights: hasExternalWeights,
            inputDescriptions: inputDescs.sorted(),
            outputDescriptions: outputDescs.sorted(),
            computeUnitsLabel: computeUnitsLabel,
            totalSizeMB: totalMB
        )
    }
    
    private func describeFeature(_ desc: MLFeatureDescription) -> String {
        if let constraint = desc.multiArrayConstraint {
            let shapeStr = constraint.shape.map { "\($0.intValue)" }.joined(separator: "×")
            return "MultiArray [\(shapeStr)]"
        } else if let imgConstraint = desc.imageConstraint {
            return "Image (\(imgConstraint.pixelsWide)×\(imgConstraint.pixelsHigh))"
        }
        return "\(desc.type)"
    }
    
    private func findItem(withExtension ext: String, in rootURL: URL) -> URL? {
        if rootURL.pathExtension.lowercased() == ext.lowercased() {
            return rootURL
        }
        guard let enumerator = FileManager.default.enumerator(
            at: rootURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return nil }
        
        while let url = enumerator.nextObject() as? URL {
            if url.pathExtension.lowercased() == ext.lowercased() {
                return url
            }
        }
        return nil
    }
    
    private func directorySizeInMB(at url: URL) -> Double {
        var total: UInt64 = 0
        if let attrs = try? FileManager.default.attributesOfItem(atPath: url.path),
           let sz = attrs[.size] as? UInt64, sz > 0 {
            total += sz
        }
        if let enumerator = FileManager.default.enumerator(at: url, includingPropertiesForKeys: [.fileSizeKey]) {
            for case let fileURL as URL in enumerator {
                if let attrs = try? FileManager.default.attributesOfItem(atPath: fileURL.path),
                   let sz = attrs[.size] as? UInt64 {
                    total += sz
                }
            }
        }
        return Double(total) / (1024.0 * 1024.0)
    }
    
    public func exportToFiles(_ urls: [URL]) {
        activeExportURLs = urls
        showFileExporter = true
    }
    
    public func shareItems(_ urls: [URL]) {
        activeExportURLs = urls
        showShareSheet = true
    }
}

// MARK: - Modularized Main ContentView (Fast Type-Checking for Swift Playgrounds)

public typealias CoreMLConverterRootView = ContentView

public struct ContentView: View {
    @StateObject private var viewModel = CoreMLPackageConverterViewModel()
    @State private var showLocalPackagePicker = false
    @State private var showSinSRInfoSheet = false
    
    public init() {}
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    searchAndActionHeaderCard
                    if viewModel.isBusy {
                        activeProgressBannerCard
                    }
                    if !viewModel.convertedArtifacts.isEmpty {
                        convertedModelsShelfCard
                    }
                    catalogListSection
                    if !viewModel.hfSearchResults.isEmpty {
                        hfSearchResultsSection
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle(".mlpackage → .mlmodel Studio")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Sync Zoo") {
                        viewModel.refreshRemoteManifest()
                    }
                    .font(.caption.bold())
                }
            }
            .sheet(isPresented: $showLocalPackagePicker) {
                LocalMLPackagePickerRepresentable(
                    onPick: { urls in
                        showLocalPackagePicker = false
                        viewModel.handlePickedLocalURLs(urls)
                    },
                    onCancel: {
                        showLocalPackagePicker = false
                    }
                )
            }
            .sheet(isPresented: $viewModel.showFileExporter) {
                SaveToFilesDocumentExporterRepresentable(urlsToExport: viewModel.activeExportURLs) {
                    viewModel.showFileExporter = false
                }
            }
            .sheet(isPresented: $viewModel.showShareSheet) {
                ConverterShareSheetRepresentable(activityItems: viewModel.activeExportURLs)
            }
            .sheet(isPresented: $showSinSRInfoSheet) {
                SinSRThreePackageExplanationSheet()
            }
            .alert(
                "Converter Notice",
                isPresented: Binding(
                    get: { viewModel.errorMessage != nil },
                    set: { if !$0 { viewModel.errorMessage = nil } }
                )
            ) {
                Button("OK", role: .cancel) { viewModel.errorMessage = nil }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
        }
    }
    
    // MARK: - Subview 1: Search & Local File Picker Header
    private var searchAndActionHeaderCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.teal)
                TextField("Search models (Real-ESRGAN, GFPGAN, FaceParsing, SinSR)...", text: $viewModel.searchQuery)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .onSubmit {
                        viewModel.searchHuggingFaceCoreMLRepos()
                    }
                if !viewModel.searchQuery.isEmpty {
                    Button {
                        viewModel.searchQuery = ""
                        viewModel.hfSearchResults = []
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                    }
                }
                Button("Search HF") {
                    viewModel.searchHuggingFaceCoreMLRepos()
                }
                .font(.system(size: 12, weight: .bold))
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.teal, in: Capsule())
                .foregroundStyle(.black)
            }
            .padding(12)
            .background(Color.secondary.opacity(0.14), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(CoreMLPackageConverterViewModel.categories, id: \.id) { cat in
                        CategoryChipView(
                            title: cat.title,
                            icon: cat.icon,
                            isSelected: viewModel.selectedCategory == cat.id
                        ) {
                            withAnimation(.spring(response: 0.25, dampingFraction: 0.8)) {
                                viewModel.selectedCategory = cat.id
                            }
                        }
                    }
                }
            }
            
            HStack(spacing: 10) {
                Button {
                    showLocalPackagePicker = true
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "folder.badge.gearshape")
                        Text("Choose Local .mlpackage / .zip from Files")
                    }
                    .font(.system(size: 13, weight: .bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
                    .background(Color.teal, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .foregroundStyle(.black)
                }
                
                Button {
                    showSinSRInfoSheet = true
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: "questionmark.circle.fill")
                        Text("SinSR Info")
                    }
                    .font(.system(size: 12, weight: .bold))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 11)
                    .background(Color.secondary.opacity(0.16), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .foregroundStyle(.teal)
                }
            }
            
            HStack(spacing: 8) {
                Image(systemName: "link")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                TextField("Or paste direct .mlpackage.zip URL...", text: $viewModel.customDownloadURLString)
                    .font(.caption)
                    .keyboardType(.URL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                if let url = URL(string: viewModel.customDownloadURLString.trimmingCharacters(in: .whitespacesAndNewlines)),
                   !viewModel.customDownloadURLString.isEmpty {
                    Button("Convert URL") {
                        viewModel.downloadAndConvertFromURL(url)
                        viewModel.customDownloadURLString = ""
                    }
                    .font(.system(size: 11, weight: .bold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.teal, in: Capsule())
                    .foregroundStyle(.black)
                }
            }
            .padding(10)
            .background(Color.secondary.opacity(0.09), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        }
        .padding(16)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .padding(.horizontal)
    }
    
    // MARK: - Subview 2: Active Conversion Progress Card
    private var activeProgressBannerCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                ProgressView().tint(.teal)
                Text(viewModel.busyStatusText)
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                Spacer()
                Text("\(Int(viewModel.downloadProgress * 100))%")
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .foregroundStyle(.teal)
                Button("Cancel") {
                    viewModel.cancelCurrentOperation()
                }
                .font(.caption.bold())
                .foregroundStyle(.red)
            }
            ProgressView(value: viewModel.downloadProgress, total: 1.0)
                .tint(.teal)
        }
        .padding(14)
        .background(Color.teal.opacity(0.14), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.teal, lineWidth: 1))
        .padding(.horizontal)
    }
    
    // MARK: - Subview 3: Converted Models Shelf
    private var convertedModelsShelfCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Converted Models Ready (\(viewModel.convertedArtifacts.count))", systemImage: "checkmark.seal.fill")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.green)
                Spacer()
                Button("Save All to Files") {
                    let allURLs = viewModel.convertedArtifacts.compactMap { $0.compiledMLModelBundleURL ?? $0.extractedRawMLModelURL }
                    viewModel.exportToFiles(allURLs)
                }
                .font(.system(size: 12, weight: .bold))
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(Color.teal, in: Capsule())
                .foregroundStyle(.black)
            }
            
            ForEach(viewModel.convertedArtifacts) { item in
                ConvertedArtifactCardView(
                    item: item,
                    onExportFiles: { urls in viewModel.exportToFiles(urls) },
                    onShare: { urls in viewModel.shareItems(urls) }
                )
            }
        }
        .padding(16)
        .background(Color.green.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.green.opacity(0.4), lineWidth: 1))
        .padding(.horizontal)
    }
    
    // MARK: - Subview 4: Searchable Core ML Model Zoo Catalog
    private var catalogListSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Core ML Model Zoo (.mlpackage Catalog)", systemImage: "shippingbox.fill")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                Spacer()
                Text("\(viewModel.filteredZooModels.count) models")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            ForEach(viewModel.filteredZooModels) { entry in
                ZooModelEntryCardView(
                    entry: entry,
                    isBusy: viewModel.isBusy,
                    onSelectFile: { file in
                        viewModel.downloadAndConvert(file: file)
                    }
                )
            }
        }
        .padding(.horizontal)
    }
    
    // MARK: - Subview 5: Live Hugging Face Search Results
    private var hfSearchResultsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Hugging Face Core ML Repositories", systemImage: "globe")
                .font(.system(size: 14, weight: .bold))
            
            ForEach(viewModel.hfSearchResults) { repo in
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(repo.id)
                            .font(.system(size: 13, weight: .bold, design: .monospaced))
                        Text("Task: \(repo.pipeline_tag ?? "coreml") • Downloads: \(repo.downloads ?? 0)")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if let repoURL = URL(string: "https://huggingface.co/\(repo.id)/tree/main") {
                        Link("Browse Files", destination: repoURL)
                            .font(.system(size: 11, weight: .bold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.teal.opacity(0.2), in: Capsule())
                            .foregroundStyle(.teal)
                    }
                }
                .padding(10)
                .background(Color.secondary.opacity(0.10), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
        }
        .padding(.horizontal)
    }
}

// MARK: - Extracted Lightweight Row & Card Views (Prevents Swift Type-Checker Timeout)

struct CategoryChipView: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: icon)
                    .font(.system(size: 11))
                Text(title)
                    .font(.system(size: 12, weight: .bold))
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(isSelected ? Color.teal : Color.secondary.opacity(0.12), in: Capsule())
            .foregroundStyle(isSelected ? .black : .primary)
        }
    }
}

struct ConvertedArtifactCardView: View {
    let item: ConvertedModelArtifact
    let onExportFiles: ([URL]) -> Void
    let onShare: ([URL]) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(item.baseName).mlmodel")
                        .font(.system(size: 15, weight: .bold, design: .monospaced))
                        .foregroundStyle(.teal)
                    Text(String(format: "%.1f MB • Compute: %@", item.totalSizeMB, item.computeUnitsLabel))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            
            if !item.inputDescriptions.isEmpty || !item.outputDescriptions.isEmpty {
                VStack(alignment: .leading, spacing: 2) {
                    if !item.inputDescriptions.isEmpty {
                        Text("Inputs: \(item.inputDescriptions.joined(separator: ", "))")
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                    if !item.outputDescriptions.isEmpty {
                        Text("Outputs: \(item.outputDescriptions.joined(separator: ", "))")
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.black.opacity(0.2), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            }
            
            HStack(spacing: 8) {
                if let mlmodelURL = item.compiledMLModelBundleURL {
                    Button {
                        onExportFiles([mlmodelURL])
                    } label: {
                        Label("Save .mlmodel to Files", systemImage: "square.and.arrow.down.fill")
                            .font(.system(size: 12, weight: .bold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 9)
                            .background(Color.teal, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .foregroundStyle(.black)
                    }
                }
                
                if let rawSpec = item.extractedRawMLModelURL {
                    Button {
                        var toExport = [rawSpec]
                        if let w = item.weightsFileURL { toExport.append(w) }
                        onExportFiles(toExport)
                    } label: {
                        Label("Raw Spec", systemImage: "doc.badge.gearshape")
                            .font(.system(size: 11, weight: .semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 9)
                            .background(Color.secondary.opacity(0.18), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                }
                
                if let mlmodelcURL = item.compiledMLModelCURL {
                    Button {
                        onExportFiles([mlmodelcURL])
                    } label: {
                        Label(".mlmodelc", systemImage: "cpu")
                            .font(.system(size: 11, weight: .semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 9)
                            .background(Color.secondary.opacity(0.18), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                }
                
                Button {
                    let urls = [item.compiledMLModelBundleURL, item.compiledMLModelCURL, item.sourcePackageURL].compactMap { $0 }
                    onShare(urls)
                } label: {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 12, weight: .bold))
                        .padding(9)
                        .background(Color.secondary.opacity(0.18), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.10), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

struct ZooModelEntryCardView: View {
    let entry: ZooModelEntry
    let isBusy: Bool
    let onSelectFile: (ZooModelFile) -> Void
    
    private var modelFiles: [ZooModelFile] {
        entry.files.filter { ($0.kind ?? "model") == "model" }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(entry.name)
                            .font(.system(size: 15, weight: .bold))
                        if entry.files.count > 1 {
                            Text("\(entry.files.count) Packages")
                                .font(.system(size: 10, weight: .black, design: .rounded))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.orange.opacity(0.22), in: Capsule())
                                .foregroundStyle(.orange)
                        }
                    }
                    Text(entry.subtitle)
                        .font(.caption)
                        .foregroundStyle(.teal)
                    Text(entry.description_md)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer()
            }
            
            VStack(spacing: 6) {
                ForEach(modelFiles) { file in
                    HStack {
                        Image(systemName: "cube.box.fill")
                            .foregroundStyle(.teal)
                            .font(.system(size: 13))
                        VStack(alignment: .leading, spacing: 1) {
                            Text(file.name.replacingOccurrences(of: ".zip", with: ""))
                                .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            Text("Size: \(file.formattedSize) • Compute: \(file.compute_units ?? "all")")
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button {
                            onSelectFile(file)
                        } label: {
                            HStack(spacing: 4) {
                                Image(systemName: "arrow.down.circle.fill")
                                Text("Convert → .mlmodel")
                            }
                            .font(.system(size: 11, weight: .bold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.teal, in: Capsule())
                            .foregroundStyle(.black)
                        }
                        .disabled(isBusy)
                    }
                    .padding(8)
                    .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
            }
        }
        .padding(14)
        .background(Color.secondary.opacity(0.11), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

// MARK: - SinSR 3-Package Architecture Explanation Sheet

struct SinSRThreePackageExplanationSheet: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            List {
                Section("Is There a Single SinSR.mlmodel File?") {
                    Text("No — in the Core ML Model Zoo (mlboydaisuke/coreml-zoo), SinSR is intentionally split into 3 separate .mlpackage files (517 MB total) rather than a single .mlmodel file.")
                        .font(.callout)
                }
                
                Section("Why SinSR Requires 3 Separate Packages") {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("1. SinSR_Encoder.mlpackage (39 MB • .cpuAndGPU)")
                            .font(.subheadline.bold())
                            .foregroundStyle(.teal)
                        Text("VQ-VAE Encoder: Encodes the 1024×1024 input image into a 1×3×256×256 Float16 latent representation on the GPU.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 2)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("2. SinSR_Denoiser.mlpackage (420 MB • .cpuOnly FP32)")
                            .font(.subheadline.bold())
                            .foregroundStyle(.orange)
                        Text("Swin Transformer UNet: Performs the single-step diffusion denoising. Must run on .cpuOnly in FP32 because FP16 self-attention overflows on the GPU/Neural Engine.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 2)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("3. SinSR_Decoder.mlpackage (58 MB • .cpuAndGPU)")
                            .font(.subheadline.bold())
                            .foregroundStyle(.teal)
                        Text("VQ-VAE Decoder: Decodes the denoised 1×3×256×256 latent back into the final 1024×1024 super-resolved image on the GPU.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 2)
                }
                
                Section("Single-File Alternative for Video Super-Resolution") {
                    Text("If you want a single one-file Super-Resolution model that accepts an image directly and outputs a 4× upscaled image in one pass (with full Apple Neural Engine .all acceleration), use RealESRGAN_x4.mlpackage.zip (62 MB) alongside GFPGAN.mlpackage.zip (312 MB) and FaceParsing.mlpackage.zip (49 MB).")
                        .font(.caption)
                }
            }
            .navigationTitle("SinSR 3-Package Pipeline")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

// MARK: - UIKit File Pickers & Exporters

struct LocalMLPackagePickerRepresentable: UIViewControllerRepresentable {
    var onPick: ([URL]) -> Void
    var onCancel: () -> Void
    
    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel)
    }
    
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        var types: [UTType] = [.zip, .folder, .package, .item, .data]
        for ext in ["mlpackage", "mlmodel", "mlmodelc"] {
            if let ut = UTType(filenameExtension: ext) {
                types.append(ut)
            }
        }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
    
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        let onCancel: () -> Void
        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

struct SaveToFilesDocumentExporterRepresentable: UIViewControllerRepresentable {
    let urlsToExport: [URL]
    var onComplete: () -> Void
    
    func makeCoordinator() -> Coordinator {
        Coordinator(onComplete: onComplete)
    }
    
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let controller = UIDocumentPickerViewController(forExporting: urlsToExport, asCopy: true)
        controller.delegate = context.coordinator
        controller.shouldShowFileExtensions = true
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
    
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onComplete: () -> Void
        init(onComplete: @escaping () -> Void) {
            self.onComplete = onComplete
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onComplete()
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onComplete()
        }
    }
}

struct ConverterShareSheetRepresentable: UIViewControllerRepresentable {
    let activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
